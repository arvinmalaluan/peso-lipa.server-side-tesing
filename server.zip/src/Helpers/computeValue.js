module.exports = {
  increaseCount: (value, increaseBy) => {
    return value + increaseBy;
  },
};
